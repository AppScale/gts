require 'monitor'
require 'net/smtp'

module Common
  def self.average(vals)
    total = 0.0
    vals.each { |val| total += val }
    total /= vals.length
  end

  def self.variance(population)
    n = 0
    mean = 0.0
    s = 0.0
    population.each { |x|
      n = n + 1
      delta = x - mean
      mean = mean + (delta / n)
      s = s + delta * (x - mean)
    }
    return s / n
  end  

  def self.std_dev(population)
    Math.sqrt(variance(population))
  end

  def self.send_email(from, to, message)
    msg = <<END_OF_MESSAGE
From: Me <#{from}>
To: You <#{to}>
Subject: AppScale Testing Results
	
#{message}
END_OF_MESSAGE
	
    Net::SMTP.start('localhost') do |smtp|
      smtp.send_message msg, from, to
    end
  end

  def self.get_range(max, my_bucket, total_buckets)
    size = max / total_buckets
    start = my_bucket * size + 1
    if my_bucket == total_buckets - 1
      fin = max
    else
      fin = (my_bucket + 1) * size
    end

    return (start..fin)
  end

  def self.get(ips, runs, contend=false, random=false)
    threads = []
    times = [] 
    failures = 0
    lock = Monitor.new

    ips.each_with_index { |addr, i|
      threads << Thread.new(addr) { |url|
        if contend
          real_runs = (1..runs)
        else
          real_runs = Common.get_range(runs, i, ips.length)
        end
        real_runs.each { |j| 
          if random
            key = rand(1 + real_runs.end)
          else
            key = j
          end

          st = Time.now
          val = `curl -X GET http://#{url}/resources/#{key} 2>&1 >>/dev/null; echo $?`
          et = Time.now
          val = val.chomp[-1].chr
          if val != "0"
            lock.synchronize { failures += 1 }
          end
          total = et - st
          times << total
        }
      }
    }

    threads.each { |thr| thr.join }

    average = 0.0
    times.each { |num| average += num }
    average /= times.size

    return average, failures
  end

  def self.write(ips, runs, contend=false, random=false)
    threads = []
    times = [] 
    failures = 0
    lock = Monitor.new

    # prime the db
    `curl -X POST http://#{ips[0]}/resources/a0 -d 'value=bar' 2>&1 >>/dev/null`

    ips.each_with_index { |addr, i|
      threads << Thread.new(addr) { |url|
        if contend
          real_runs = (1..runs)
        else
          real_runs = Common.get_range(runs, i, ips.length)
        end
        
        real_runs.each { |j| 
          if random
            key = rand(1 + real_runs.end)
          else
            key = j
          end

          st = Time.now
          `curl -X POST http://#{url}/resources/a#{key} -d 'value=bar' 2>&1 >>/dev/null`
          et = Time.now
          result = self.get_solo(url, key).chomp
          if result != "bar"
            abort("key #{key} wasn't bar but was #{result}")
            lock.synchronize { failures += 1 }
          end
          total = et - st
          times << total
        }
      }
    }

    threads.each { |thr| thr.join }

    average = 0.0
    times.each { |num| average += num }
    average /= times.size

    return average, failures
  end

  def self.delete(ips, runs, contend=false, random=false)
    threads = []
    times = [] 
    failures = 0
    lock = Monitor.new

    ips.each_with_index { |addr, i|
      threads << Thread.new(addr) { |url|
        if contend
          real_runs = (1..runs)
        else
          real_runs = Common.get_range(runs, i, ips.length)
        end
        real_runs.each { |j| 
          if random
            key = rand(1 + real_runs.end)
          else
            key = j
          end

          st = Time.now
          val = `curl -X DELETE http://#{url}/resources/a#{key} 2>&1 >>/dev/null; echo $?`
          et = Time.now
          val = val.chomp[-1].chr
          if val != "0"
            lock.synchronize { failures += 1 }
          end
          total = et - st
          times << total
        }
      }
    }

    threads.each { |thr| thr.join }

    average = 0.0
    times.each { |num| average += num }
    average /= times.size

    return average, failures
  end

  def self.query(ips, runs, contend=false, random=false)
    threads = []
    times = [] 
    failures = 0

    ips.each_with_index { |addr, i|
      threads << Thread.new(addr) { |url|
        if contend
          real_runs = (1..runs)
        else
          real_runs = Common.get_range(runs, i, ips.length)
        end
        real_runs.each { |j| 
          if random
            key = rand(1 + real_runs.end)
          else
            key = j
          end

          st = Time.now
          val = `curl http://#{url}/resources 2>&1 >>/dev/null; echo $?`
          et = Time.now
          val = val.chomp[-1].chr
          failures += 1 if val != "0"
          total = et - st
          times << total
        }
      }
    }

    threads.each { |thr| thr.join }

    average = 0.0
    times.each { |num| average += num }
    average /= times.size

    return average, failures
  end

 def self.noop(ips, runs, contend=false, random=false)
    threads = []
    times = [] 
    failures = 0

    ips.each_with_index { |addr, i|
      threads << Thread.new(addr) { |url|
        if contend
          real_runs = (1..runs)
        else
          real_runs = Common.get_range(runs, i, ips.length)
        end
        real_runs.each { |j| 
          if random
            key = rand(1 + real_runs.end)
          else
            key = j
          end

          st = Time.now
          val = `curl http://#{url}/ 2>&1 >>/dev/null; echo $?`
          et = Time.now
          val = val.chomp[-1].chr
          failures += 1 if val != "0"
          total = et - st
          times << total
        }
      }
    }

    threads.each { |thr| thr.join }

    average = 0.0
    times.each { |num| average += num }
    average /= times.size

    return average, failures
  end

  def self.get_solo(url, key)
    `curl http://#{url}/resources/a#{key} 2>/dev/null`
  end
end
