# Programmer: Chris Bunch
# will eventually be used to test databases
# not yet though :)
require 'common'

global_start = Time.now()

w_avgs = []
g_avgs = []
q_avgs = []
d_avgs = []
n_avgs = []
ips = ["gae-dbtest.appspot.com"]
max = 1000

5.times { |run|
  puts "starting run #{run}"
  n_avg, fails = Common.noop(ips, max, contend=true, random=false)
  puts "finished noop #{run}, with an average of #{n_avg} [and #{fails} fails]."
  n_avgs << n_avg
  w_avg, fails = Common.write(ips, max, contend=true, random=false)
  puts "finished write #{run}, with an average of #{w_avg} [and #{fails} fails]."
  w_avgs << w_avg
  g_avg, fails = Common.get(ips, max, contend=true, random=true)
  puts "finished get #{run}, with an average of #{g_avg} [and #{fails} fails]."
  g_avgs << g_avg
  q_avg, fails = Common.query(ips, 100, contend=true, random=false)
  puts "finished query #{run}, with an average of #{q_avg} [and #{fails} fails]."
  q_avgs << q_avg
  d_avg, fails = Common.delete(ips, max, contend=true, random=false)
  puts "finished delete #{run}, with an average of #{d_avg} [and #{fails} fails]."
  d_avgs << d_avg
}

global_end = Time.now()
global_total = global_end - global_start

puts "average noop times   = [#{n_avgs.join(', ')}]"
puts "average write times  = [#{w_avgs.join(', ')}]"
puts "average get times    = [#{g_avgs.join(', ')}]"
puts "average query times  = [#{q_avgs.join(', ')}]"
puts "average delete times = [#{d_avgs.join(', ')}]"
puts "total run time = #{global_total} seconds (which is #{global_total/60.0} minutes)"
