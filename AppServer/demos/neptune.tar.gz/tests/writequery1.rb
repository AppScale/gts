# Programmer: Chris Bunch
# will eventually be used to test databases
# not yet though :)
require 'common'

global_start = Time.now()

averages = []
ips = ["gae-dbtest.appspot.com", "gae-dbtest.appspot.com", "gae-dbtest.appspot.com"]
max = 10000
queries = 100

puts "starting write"
Common.write(ips, max, contend=true, random=false)

5.times { |run|
  puts "starting query #{run}"
  average = Common.query(ips, queries, contend=true, random=false)
  File.open("/tmp/timing-#{run}", "w+") { |file| file.write(average) }
  puts "finished query #{run}, with an average of #{average}."
  averages << average
}

#Common.delete(ips, max, contend=true, random=false)
global_end = Time.now()
global_total = global_end - global_start

message = "The average query times for this database were [#{averages.join(', ')}] seconds. We did #{max} puts and #{queries} queries for each of the 5 runs on this database, taking a total of #{global_total} seconds."
puts message
#Common.send_email(MAIL, MAIL, message)
