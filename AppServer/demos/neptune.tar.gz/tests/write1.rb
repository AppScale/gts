# Programmer: Chris Bunch
# will eventually be used to test databases
# not yet though :)
require 'common'
MAIL = "cgb@cs.ucsb.edu"

global_start = Time.now()

averages = []
ips = ["localhost:8081"] # test local sdk
runs = 10

1.times { |run|
  average = Common.write(ips, runs, contend=true, random=false)
  File.open("/tmp/timing-#{run}", "w+") { |file| file.write(average) }
  #Common.delete(ips, runs) if run != 4
  averages << average
}

global_end = Time.now()
global_total = global_end - global_start

message = "The average put times for this database were [#{averages.join(', ')}] seconds. We did #{runs} puts for each of the 5 runs on this database, taking a total of #{global_total} seconds."
puts message
#Common.send_email(MAIL, MAIL, message)
