# Programmer: Chris Bunch
# will eventually be used to test databases
# not yet though :)
require 'common'

global_start = Time.now()

write_pct = 30
get_pct = 50
query_pct = 20
delete_pct = 0
noop_pct = 0

total_pct = write_pct + get_pct + query_pct + delete_pct + noop_pct
if total_pct != 100
  abort("total pct was #{total_pct}, not 100. please adjust accordingly.")
end

write_range = Range.new(0, write_pct)
get_range = Range.new(write_range.max, write_range.max + get_pct)
query_range = Range.new(get_range.max, get_range.max + query_pct)
delete_range = Range.new(query_range.max, query_range.max + delete_pct)
noop_range = Range.new(delete_range.max, 100)

#abort("W = #{write_range}, G = #{get_range}, Q = #{query_range}, D = #{delete_range}, N = #{noop_range}")

w_avgs = []
g_avgs = []
q_avgs = []
d_avgs = []
n_avgs = []

w_final = []
g_final = []
q_final = []
d_final = []
n_final = []

w_count = 0
g_count = 0
q_count = 0
d_count = 0
n_count = 0

ips = ["gae-dbtest.appspot.com"]
max = 10000
total_count = 5 * max

5.times { |run|
  puts "starting run #{run}"
  max.times { |access|
    rand_val = rand(100)
    if write_range.include?(rand_val)
      time, fails = Common.write(ips, 1, contend=true, random=true)
      w_avgs << time
      w_count += 1
    elsif get_range.include?(rand_val)
      time, fails = Common.get(ips, 1, contend=true, random=true)
      g_avgs << time
      g_count += 1
    elsif query_range.include?(rand_val)
      time, fails = Common.query(ips, 1, contend=true, random=false)
      q_avgs << time
      q_count += 1
    elsif delete_range.include?(rand_val)
      time, fails = Common.delete(ips, 1, contend=true, random=true)
      d_avgs << time
      d_count += 1
    else
      abort("#{rand_val}, #{noop_range}")
      time, fails = Common.noop(ips, 1, contend=false, random=false)
      n_avgs << time
      n_count += 1
    end
  }
  w_final << Common.average(w_avgs)
  g_final << Common.average(g_avgs)
  q_final << Common.average(q_avgs)
  d_final << Common.average(d_avgs)
  n_final << Common.average(n_avgs)
}

global_end = Time.now()
global_total = global_end - global_start

puts "noop   = [#{n_final.join(', ')}], (#{n_count}/#{total_count})"
puts "write  = [#{w_final.join(', ')}], (#{w_count}/#{total_count})"
puts "get    = [#{g_final.join(', ')}], (#{g_count}/#{total_count})"
puts "query  = [#{q_final.join(', ')}], (#{q_count}/#{total_count})"
puts "delete = [#{d_final.join(', ')}], (#{d_count}/#{total_count})"
puts "total run time = #{global_total} seconds (which is #{global_total/60.0} minutes)"
