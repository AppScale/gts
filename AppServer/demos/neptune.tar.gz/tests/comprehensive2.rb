# Programmer: Chris Bunch
# will eventually be used to test databases
# not yet though :)
require 'common'

global_start = Time.now()

w_avgs = []
g_avgs = []
q_avgs = []
d_avgs = []
ips = ["localhost:8080"] # test local sdk
max = 10

1.times { |run|
  puts "starting run #{run}"
  w_avg, fails = Common.write(ips, max, contend=true, random=false)
  puts "finished contend write #{run}, with an average of #{w_avg} [and #{fails} fails]."
  w_avgs << w_avg
  g_avg, fails = Common.write(ips, max, contend=false, random=false)
  puts "finished non-contend write #{run}, with an average of #{g_avg} [and #{fails} fails]."
  g_avgs << g_avg
}

global_end = Time.now()
global_total = global_end - global_start

puts "average contend write times     = [#{w_avgs.join(', ')}]"
puts "average non-contend write times = [#{g_avgs.join(', ')}]"
puts "total run time = #{global_total} seconds (which is #{global_total/60.0} minutes)"
