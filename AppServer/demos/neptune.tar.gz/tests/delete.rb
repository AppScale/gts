# Programmer: Chris Bunch
# will eventually be used to test databases
# not yet though :)
require 'common'

global_start = Time.now()

averages = []
ips = ["gae-dbtest.appspot.com"]
max = 1000

puts "starting delete"
Common.delete(ips, max, contend=false, random=false)

puts "DONE!"
#Common.send_email(MAIL, MAIL, message)
