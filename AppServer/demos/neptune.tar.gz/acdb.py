#!/usr/bin/env python
#
# Programmers: Chris Bunch and Jonathan Kupferman
# Provides a REST API to the underlying database
# See http://appscale.cs.ucsb.edu for more info

import cgi
import datetime
import logging
import os
import re
import wsgiref.handlers
import urllib
import cPickle
import time

from google.appengine.ext import db
from google.appengine.api import urlfetch
from google.appengine.api import users
from google.appengine.ext import webapp
from google.appengine.api import memcache
from google.appengine.ext.webapp import template
from google.appengine.datastore import entity_pb

HOST = os.environ["HTTP_HOST"]

OPERATION_SUCCESSFUL = "success!\n"
KEY_NOT_FOUND = "key didn't exist\n"

class Entry(db.Model):
  content = db.StringProperty(multiline=True)

class Home(webapp.RequestHandler):
  def get(self):
    response = """Active Cloud DB is a Google App Engine application that
exposes a RESTful API to the Google Datastore API. In short, this means that
you can use Active Cloud DB as a web interface to any database that supports
the Google Datastore API. It runs seamlessly over Google's BigTable as well
as any datastore supported by AppScale, the open-source implementation of
the Google App Engine APIs. As of this writing, you can use Active Cloud DB
over the following datastores when running over AppScale:
<ul>
  <li>HBase</li>
  <li>Hypertable</li>
  <li>MySQL</li>
  <li>Cassandra</li>
  <li>Voldemort</li>
  <li>MongoDB</li>
  <li>MemcacheDB</li>
  <li>Scalaris</li>
</ul>
<hr />
<p>You can use the web interface here to manually get, put, query, and delete
items. Alternatively, the RESTful interface works as follows. Items are stored
as a key-value pair within the underlying datastore. Users can get the value
for a given item by specifying its key, store an item by specifying its key
and value, or deleting an item by specifying its key. Alternatively, users
can query the datastore, which returns all the keys and values in the datastore.
This can be done in a RESTful fashion by making these types of requests:</p>
<ul>
<li>Get operation: Perform a GET request to 
<br />http://{this ip}:{this port}/resources/keyname</li>
  <li>Put operation: Perform a POST request to 
<br />http://{this ip}:{this port}/resources/keyname
<br />with the value encoded in the
request parameters (using the parameters {'value':value}).</li>
  <li>Query operation: Perform a GET request to 
<br />http://{this ip}:{this port}/resources</li>
  <li>Delete operation: Perform a DELETE request to 
<br />http://{this ip}:{this port}/resources/keyname</li>
</ul>
"""

    self.response.out.write(template.render('index.html',
                                            {'operation': 'About Active Cloud DB',
                                            'result': response}))

class GetInterface(webapp.RequestHandler):
  def get(self):
    response = "Name the key of the item you wish to retrieve:<br /><br />"
    response += "<form action='/get' method='post'>"
    response += "<div><textarea name='key' rows='1' cols='20'></textarea></div>"
    response += "<div><input type='submit' name='get' value='Retrieve Item' /></div><br />"
    response += "</form>"
    self.response.out.write(template.render('index.html',
                                            {'operation': 'Get an Item',
                                             'result': response}))

  def post(self):
    key = self.request.get('key')

    if key is not None and key != '':
      url = "http://" + HOST + "/resources/" + key
      result = urlfetch.fetch(url=url, method=urlfetch.GET)

      if result.content == KEY_NOT_FOUND:
        response = "No value was found for the key you specified."
      else:
        response = "We found a value for the key you specified. It was:"
        response += "<p>" + result.content + "</p>"
    else:
      response = "Please specify a key to acquire and try again."

    self.response.out.write(template.render('index.html',
                                            {'operation': 'Get an Item',
                                             'result': response}))

class PutInterface(webapp.RequestHandler):
  def get(self):
    response =  "<form action='/put' method='post'>"
    response += "<div>Name the key of the item you wish to store:</div>"
    response += "<div><textarea name='key' rows='1' cols='20'></textarea></div>"
    response += "<div>Name the value of the item you wish to store:</div>"
    response += "<div><textarea name='value' rows='1' cols='20'></textarea></div>"
    response += "<div><input type='submit' name='get' value='Store Item' /></div><br />"
    response += "</form>"
    self.response.out.write(template.render('index.html',
                                            {'operation': 'Put an Item',
                                             'result': response}))

  def post(self):
    key = self.request.get('key')
    value = self.request.get('value')

    valid_key = (key != None) and (key != '')
    valid_val = (value != None) and (value != '')

    if valid_key and valid_val:
      url = "http://" + HOST + "/resources/" + key
      form_fields = {"value":value}
      form_data = urllib.urlencode(form_fields)
      result = urlfetch.fetch(url=url,
                          payload=form_data,
                          method=urlfetch.POST,
                          headers={'Content-Type': 'application/x-www-form-urlencoded'})

      if result.content == OPERATION_SUCCESSFUL:
        response = "The key and value you specified were saved in the database."
      else:
        response = "There was a problem saving your data. It was:"
        response += "<p>" + result.content + "</p>"
    else:
      response = "Please specify a key and value to store and try again."

    self.response.out.write(template.render('index.html',
                                            {'operation': 'Put an Item',
                                             'result': response}))

class QueryInterface(webapp.RequestHandler):
  def get(self):
    url = "http://" + HOST + "/resources"
    result = urlfetch.fetch(url=url, method=urlfetch.GET)

    if result.content == "":
      response = "No items are currently in the database."
    else:
      response = "The following items are in the database:<br /><br />"
      keyvals = re.findall("([\d\w]+|[\d\w]+||)", result.content)
      key = 0
      val = 1
      on = key

      response += "<table border='1' width='40%' length='40%'>"
      response += "<tr><td>Key</td><td>Value</td></tr>"

      current_key = ""
      current_val = ""
      for item in keyvals:
        if not item == "":
          if on == key:
            current_key = item
            on = val
          else:
            current_val = item
            on = key
            response += "<tr><td>" + current_key + "</td><td>" + current_val + "</td></tr>"

      response += "</table>"

    self.response.out.write(template.render('index.html',
                                            {'operation': 'Query the Database',
                                             'result': response}))

class DeleteInterface(webapp.RequestHandler):
  def get(self):
    response = "Name the key of the item you wish to delete:<br /><br />"
    response += "<form action='/delete' method='post'>"
    response += "<div><textarea name='key' rows='1' cols='20'></textarea></div>"
    response += "<div><input type='submit' name='get' value='Delete Item' /></div><br />"
    response += "</form>"
    self.response.out.write(template.render('index.html',
                                            {'operation': 'Delete an Item',
                                             'result': response}))

  def post(self):
    key = self.request.get('key')
    
    if key is not None and key != '':
      url = "http://" + HOST + "/resources/" + key
      result = urlfetch.fetch(url=url, method=urlfetch.DELETE)

      if result.content == OPERATION_SUCCESSFUL:
        response = "The key you specified and any associated value was removed from the database."
      else:
        response = "There was an error deleting the key/value pair from the database. It was:"
        response += "<p>" + result.content + "</p>"
    else:
      response = "Please specify a key to delete and try again."

    self.response.out.write(template.render('index.html',
                                            {'operation': 'Delete an Item',
                                             'result': response}))

class NoOp(webapp.RequestHandler):
  def get(self):
    self.response.out.write("hello\n")

  def post(self):
    self.response.out.write("hello\n")

class Count(webapp.RequestHandler):
  def get(self):
    count = db.GqlQuery("SELECT * FROM Entry").count()
    self.response.out.write(str(count))

class ResourcesKey(webapp.RequestHandler):
  def get(self, key):
    cached = memcache.get(key)
    if cached:
      entry = decode(cached)
    else:
      entry = Entry.get_by_key_name(key)

    try:
      self.response.out.write(entry.content + "\n")
      if not cached:
        memcache.set(key, encode(entry))
    except AttributeError:
      self.response.out.write(KEY_NOT_FOUND)

  def post(self, key):
    entry = Entry(key_name = key)
    value = self.request.get('value')
    entry.content = value
    entry.put()
    self.response.out.write(OPERATION_SUCCESSFUL)
    memcache.set(key, encode(entry))
    bump_generation()

  def delete(self, key):
    entry = Entry(key_name = key)
    entry.delete()
    self.response.out.write(OPERATION_SUCCESSFUL)

    memcache.delete(key)
    bump_generation()

class Resources(webapp.RequestHandler):
  def get(self):
    query = "SELECT * FROM Entry"
    cachekey = cache_key(query)

    cached = memcache.get(cachekey)
    if cached:
      #self.response.out.write("HIT!")
      # Unpickle and the list and decode each object
      entries = [decode(x) for x in cPickle.loads(cached)]
    else:
      #self.response.out.write("MISS!")
      # Iterate through the results to make sure they are fetched from the db
      entries = [g for g in db.GqlQuery(query)]

      # Encode the entries and then pickle the list
      encoded = [encode(x) for x in entries]
      memcache.set(cachekey, cPickle.dumps(encoded))

    for entry in entries:
      self.response.out.write('%s|%s||' % (entry.key().name(), cgi.escape(entry.content)))

application = webapp.WSGIApplication([
  ('/', Home),
  ('/get', GetInterface),
  ('/put', PutInterface),
  ('/query', QueryInterface),
  ('/delete', DeleteInterface),
  ('/count', Count),
  ('/resources', Resources),
  (r'/resources/(.*)', ResourcesKey)
], debug=True)

# Encode the database object into a protocol buffer
def encode(value):
  return db.model_to_protobuf(value).Encode()
# Decode the protocol buffer back into a database object
def decode(value):
  return db.model_from_protobuf(entity_pb.EntityProto(value))

APPLICATION_NAME="activeclouddb"
GENERATION_KEY="GEN/%s" % APPLICATION_NAME

def generation():
  # If the generation is not in the cache initialize it to the current time
  # just so that it is unlikely to loop around
  # Cant this be cached per request?
  return memcache.get(GENERATION_KEY)

def bump_generation():
  result = memcache.incr(GENERATION_KEY, initial_value=int(time.time()))
  # in case that key was for some reason not set to an integer, incr will return none
  if result is None:
    memcache.set(GENERATION_KEY, int(time.time()))

WHITESPACE = re.compile(r'\s+')
def cache_key(key):
  # Memcache does not allow any whitespace in keys, so strip it out
  cleaned_key = re.sub(WHITESPACE,'', key)
  return "%s/%s/%s" % (APPLICATION_NAME, generation(), cleaned_key)

def main():
  wsgiref.handlers.CGIHandler().run(application)

if __name__ == '__main__':
  main()
