from django.shortcuts import render_to_response

import os

# bad way to do this - should put it in a separate file
# but since this is a small demo project it is ok for now

# if running on google's infrastructure
DB_LOCATION = "active-cloud-db.appspot.com"
# if running on appscale
#DB_LOCATION = "192.168.1.3:8080" # update accordingly

class DBHelper():
  @staticmethod
  def get(key):
    cmd = "curl -X GET http://" + DB_LOCATION + "/resources/" + key
    output = os.popen(cmd).read()
    if output == "" or output == "key didn't exist\n":
      output = None
    return output

  @staticmethod
  def put(key, val):
    cmd = "curl -X POST http://" + DB_LOCATION + "/resources/" + key + " -d 'value=" + val + "'"
    output = os.popen(cmd).read()
    return output

# Create your views here.

def add(request):
  # nothing to do here, the view handles it for us
  return render_to_response('add.html', {})

def listbooks(request):
  book_data = ""
  book_list = DBHelper.get("book_list")
  if book_list is None:
    book_data = "No books are currently in the system."
  else:
    books = book_list.split(">>>")[1:]
    book_count = str(len(books))
    book_data += book_count + " books currently in the system:<br /><br />"
    book_data += "<hr />"
   
    for title in books:
      summary = DBHelper.get(title)
      book_data += "Book Title: " + title + "<br /><br />"
      book_data += "Book Summary: " + summary + "<br />"
      book_data += "<hr />"

  return render_to_response('index.html', {'layout' : book_data})

def addpost(request):
  try:
    title = request.POST['title']
  except KeyError:
    title = None

  try:
    summary = request.POST['summary']
  except KeyError:
    summary = None

  errors = []
  if title is None:
    errors.append("Title cannot be left blank.")

  if summary is None:
    errors.append("Summary cannot be left blank.")

  if errors == []:
    book_list = DBHelper.get("book_list")
    if book_list is None:
      book_list = ""
    book_list = book_list.split(">>>")
    book_list.append(title)
    book_list = ">>>".join(book_list)

    DBHelper.put("book_list", book_list)
    DBHelper.put(title, summary)

    result = "Book data successfully added!"
  else:
    result = "There were errors with your submission:<br /><br />"
    result += '<br /><br />'.join(errors)

  return render_to_response('index.html', {'layout' : result})

