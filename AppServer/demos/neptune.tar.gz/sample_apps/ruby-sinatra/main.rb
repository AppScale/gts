require 'rubygems'
require 'haml'
require 'sinatra'

DB_LOCATION = "128.111.55.209:8080"

helpers do
  def db_get(key)
    val = `curl http://#{DB_LOCATION}/get -d 'key=#{key}' -L`
    val = nil if val == "key didn't exist"
    return val
  end
 
  def db_put(key, val)
    `curl http://#{DB_LOCATION}/put -d 'key=#{key}&value=#{val}' -L 2>&1`
  end

  def db_query(key)
    `curl http://#{DB_LOCATION}/query -L 2>&1`
  end

  def db_delete(key)
    `curl http://#{DB_LOCATION}/delete -d 'key=#{key}' -L 2>&1`
  end
end

get '/add' do
  # nothing really, the template makes the form for us
  haml :add
end

post '/add' do
  # save info to db
  # redirect to /view
  title = params[:title]
  summary = params[:summary]

  errors = []
  if title.empty?
    errors << "Title cannot be left blank."
  end

  if summary.empty?
    errors << "Summary cannot be left blank."
  end

  if errors.empty?
    book_list = db_get("book_list")
    book_list = "" if book_list.nil?
    book_list = book_list.split(">>>")
    book_list << title
    book_list = book_list.join(">>>")

    db_put("book_list", book_list)
    db_put(title, summary)

    result = "Book data successfully added!"
  else
    result = "There were errors with your submission:<br /><br />"
    result += errors.join('<br /><br />')
  end

  haml :index, :locals => { :layout => result }
end

get '/view' do
  # get all books key
  # for each book
  # get its key
  # format it?

  book_data = ""
  book_list = db_get("book_list")
  if book_list.nil?
    book_data = "No books are currently in the system."
  else
    books = book_list.split(">>>")
    book_data += "#{books.length} books currently in the system:<br /><br />"
    book_data += "<hr />"

    books.each { |title|
      summary = db_get(title)
      book_data += "Book Title: " + title + "<br /><br />"
      book_data += "Book Summary: " + summary + "<br />"
      book_data += "<hr />"
    }
    #book_data = "Books [#{book_list}] are currently in the system."
  end

  haml :index, :locals => { :layout => book_data }
end

get '/delete' do
  # really just make form
  baz = "Boo!"
  haml :index, :locals => { :layout => baz }
end

post '/delete' do
  # delete item from do
  # make sure to change all books key also
  haml :index
end
